package bank;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class BankingApp {

	public static void main(String[] args){
		System.out.println("############### Welcome to the Banking Service ###############");
		System.out.println("\n");
		Customer customer = new Customer();
		customer.createAccount();
	}
}
class Customer{
	String customerName;
	String dateOfBirth;
	String customerEmail;
	String customerPhone;
	String customerAddress;
	String nameOfBank;
	void createAccount() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Do you want to open a bank account Yes/No. Y/N");
		char Option = scan.nextLine().charAt(0);
		if(Option == 'Y' || Option == 'y') {
			System.out.println("---------------------------------------- ");	
		System.out.println("Choose the bank in which you want to open your account: 1.SBI 2.ICICI 3.HDFC 4.Central Bank of India");
		
			char chooseBank = scan.nextLine().charAt(0);
			System.out.println("---------------------------------------- ");
			if(chooseBank == '1') {
				System.out.println("Name of the bank is: SBI");
			}
			if(chooseBank == '2') {
				System.out.println("Name of the bank is: ICICI");
			}
			if(chooseBank == '3') {
				System.out.println("Name of the bank is: HDFC");
			}
			if(chooseBank == '4') {
				System.out.println("Name of the bank is: Central Bank of India");
			}
		System.out.println("---------------------------------------- ");
		System.out.println("Enter the type of account you want to open: 1.Saving and 2.Current");
		char chooseAccountType = scan.nextLine().charAt(0);
		System.out.println("---------------------------------------- ");
		if(chooseAccountType == '1') {
			System.out.println("Account type is: Saving");
		}
		if(chooseAccountType == '2') {
			System.out.println("Account type is: Current");
		}
		System.out.println("---------------------------------------- ");
		System.out.println("Enter your name:");
		customerName = scan.nextLine();
		System.out.println("---------------------------------------- ");
		System.out.println("Enter your date of birth:");
		dateOfBirth = scan.nextLine();
		System.out.println("---------------------------------------- ");
		System.out.println("Enter your E-mail Id:");
		customerEmail = scan.nextLine();
		System.out.println("---------------------------------------- ");
		System.out.println("Enter your Phone Number:");
		customerPhone = scan.nextLine();
		System.out.println("---------------------------------------- ");
		System.out.println("Enter your address:");
		customerAddress = scan.nextLine();
		System.out.println("---------------------------------------- ");
		accountHolderDetails();
		Account account = new Account();
		account.showMenu();
		}
		if(Option == 'N' || Option == 'n') {
			accountHolderDetails();
		}
	}
	void accountHolderDetails() {
		System.out.println("\n");
		System.out.println("**********Account Holders Details**********");
		try {
			FileOutputStream fileOut = new FileOutputStream("E:\\Jyoti\\BankingApp\\CustomerDetails.txt");
			PrintStream printIntoFile = new PrintStream(fileOut);
			
			printIntoFile.append("Account holder's name is:\n" + customerName);
		    System.out.println("Account holder's name is:\n" + customerName);
		    
		    printIntoFile.append("\n"+customerName+"'s date of birth is:\n"+ dateOfBirth);
		    System.out.println(customerName+"'s date of birth is:\n"+ dateOfBirth );
		    
		    printIntoFile.append("\n"+customerName+"'s e-mail id is:\n"+ customerEmail);
		    System.out.println(customerName+"'s e-mail id is:\n"+ customerEmail);
		    
		    printIntoFile.append("\n"+customerName+"'s phone number is:\n"+ customerPhone);
		    System.out.println(customerName+"'s phone number is:\n"+ customerPhone);
		    
		    printIntoFile.append("\n"+customerName+"'s account number is:\n"+ Math.random());
		    System.out.println(customerName+"'s account number is:\n"+ Math.random());
		    System.out.println("\n");
		}
		catch(Exception exception) {
			System.out.println("Error in printing the data" + exception);
		}
	}
}
class AccountTpye{
	void isSavingAccount(){
		final double maxwithdrawLimit = 15000;
		final double minBalance = 2000;
		BankRBI bank = new BankRBI();
		
		System.out.println("Minimum Balance allowed: "+minBalance);
		System.out.println("Maximum withdrawl Limit: "+maxwithdrawLimit);
		bank.simpleInterest();
		try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {

            e.printStackTrace();
        }
	}
	
	void isCurrentAccount() {
		final double maxwithdrawLimit = 20000;
		final double minBalance = 5000;
		BankRBI bank = new BankRBI();
		
		System.out.println("Minimum Balance allowed: "+minBalance);
		System.out.println("Maximum withdrawl Limit: "+maxwithdrawLimit);
		bank.compoundInterest();
		try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {

            e.printStackTrace();
        }
	}
}
class Account{
	int balance;
	int previousTransaction;
	String customerName;
	String accountType;
	void deposit(int amount) {
		if(amount != 0) {
			try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
			balance = balance + amount;
			previousTransaction = amount;
			try {
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
			System.out.println("---------------------------------------- ");
			System.out.println("Updated Balance: " +previousTransaction);
		}
	}
	void withdraw(int amount) {
		if(balance > previousTransaction) {
			try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
			System.out.println("---------------------------------------- ");
			System.out.println("Insufficient Balance");
			try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
		}
		else{
			balance = balance - amount;
			previousTransaction = -amount;
			System.out.println("---------------------------------------- ");
			try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
			System.out.println("Amount withdrawn successfully ");
			System.out.println("---------------------------------------- ");
			System.out.println("Remaining Amount: " +balance);
			try {
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
 
                e.printStackTrace();
            }
		}
	}	
	void getPreviousTransaction() {
		FileOutputStream fileOut;
		PrintStream printIntoFile ;
		try {
			fileOut = new FileOutputStream("E:\\Jyoti\\BankingApp\\Recipt.txt");
			printIntoFile = new PrintStream(fileOut);
					
			if(previousTransaction > 0) {
				printIntoFile.append("Amount Deposited: "+ balance);
				System.out.println("Amount Deposited: "+ balance);
				try {
	                Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	 
	                e.printStackTrace();
	            }
			}
			else if(previousTransaction < 0) {
				printIntoFile.append("Amount Withdrawn: "+ balance);
				System.out.println("Amount Withdrawn: "+ Math.abs(balance));
				try {
	                Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	 
	                e.printStackTrace();
	            }
			}
			else {
				System.out.println("There is no transaction occured");
				try {
	                Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	 
	                e.printStackTrace();
	            }
			}
			printIntoFile.close();
		}
		catch(Exception exception) {
			System.out.println("Error in printing the data" + exception);
		}
	}
	AccountTpye typeOfAccount = new AccountTpye();
	void showMenu() {
		char Option ='\0';
		Scanner scan = new Scanner(System.in);
		
		System.out.println("********** Services Available **********");
		System.out.println("\n");
		System.out.println("1. Check Balance");
		System.out.println("2. Deposit");
		System.out.println("3. Withdraw");
		System.out.println("4. Previous Transaction");
		System.out.println("5. Calculate Interest");
		System.out.println("6. Exit");
		
		do{
			System.out.println("============================================");
			System.out.println("Enter an option");
			System.out.println("============================================\n");
			Option = scan.next().charAt(0);
			
			switch(Option) {
			case '1':
				System.out.println("---------------------------------------- ");
				System.out.println("Balance = "+balance);
				try {
	                Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	 
	                e.printStackTrace();
	            }
				System.out.println("---------------------------------------- \n");
				break;
			case '2':
				System.out.println("---------------------------------------- ");
				System.out.println("Enter an amounnt to deposit: ");
				System.out.println("---------------------------------------- ");
				int amount = scan.nextInt();
				deposit(amount);
				System.out.println("---------------------------------------- ");
				System.out.println("Amount deposited successfully ");
				System.out.println("---------------------------------------- \n");
				break;
			case '3':
				System.out.println("---------------------------------------- ");
				System.out.println("Enter an amount to withdraw: ");
				System.out.println("---------------------------------------- \n");
				int amount1 = scan.nextInt();
				withdraw(amount1);				
				System.out.println("---------------------------------------- \n");
				break;
			case '4':
				System.out.println("---------------------------------------- ");
				getPreviousTransaction();
				System.out.println("---------------------------------------- \n");
				break;
			case '5':
				System.out.println("---------------------------------------- ");
				System.out.println("Enter account type to calculate interest 1.Saving 2.Current");
				int accType = scan.nextInt();
				switch(accType) {
				case 1:
					System.out.println("---------------------------------------- ");
					typeOfAccount.isSavingAccount();
					break;
				case 2:
					System.out.println("---------------------------------------- ");
					typeOfAccount.isCurrentAccount();
					break;
				}
				System.out.println("---------------------------------------- \n");
				break;
			case '6':
				System.out.println("============================================");
				break;
			default:
				System.out.println("Invalid Option!!!! Enter a correct option again");
			}
		}while(Option != '6');
		System.out.println("Thank you for using the services");
	}
}
class BankRBI{
	double finalInterest;
	double interestRate;
	double time;
	double principalAmt;
	double numOfTimes;
	void simpleInterest() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Principal Amount");
		principalAmt = scan.nextDouble();
		
		System.out.println("Enter the Interest Rate");
		interestRate = scan.nextDouble();
		
		System.out.println("Enter the time");
		time = scan.nextDouble();
		
		try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {

            e.printStackTrace();
        }
		finalInterest = (principalAmt*interestRate*time)/100;
		System.out.println("Total simple Interest: "+finalInterest);
		
	}
	void compoundInterest(){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Principal Amount");
		principalAmt = scan.nextDouble();
		
		System.out.println("Enter the Interest Rate");
		interestRate = scan.nextDouble();
		
		System.out.println("Enter the time");
		time = scan.nextDouble();
		
		System.out.println("Enter the number of times interest is compounded per year");
		numOfTimes = scan.nextDouble();
		
		try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {

            e.printStackTrace();
        }
		finalInterest = principalAmt*(Math.pow(1.0+interestRate/100.0,time))-principalAmt;
		System.out.println("Total compound Interest: "+finalInterest);
	}
}
